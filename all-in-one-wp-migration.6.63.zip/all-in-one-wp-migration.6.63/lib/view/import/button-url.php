<a href="https://servmask.com/products/url-extension" target="_blank"><?php _e( 'URL', AI1WM_PLUGIN_NAME ); ?></a>
